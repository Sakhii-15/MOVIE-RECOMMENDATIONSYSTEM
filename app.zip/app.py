from flask import Flask, render_template, request
from model import load_data, create_similarity

app = Flask(__name__)
df = load_data()
similarity = create_similarity(df)

def recommend(movie):
    movie = movie.lower()
    if movie not in df['title'].str.lower().values:
        return []
    idx = df[df['title'].str.lower() == movie].index[0]
    distances = list(enumerate(similarity[idx]))
    movies = sorted(distances, key=lambda x: x[1], reverse=True)[1:6]
    return [df.iloc[i[0]].title for i in movies]

@app.route('/', methods=['GET', 'POST'])
def index():
    recommendations = []
    movie_name = ''
    if request.method == 'POST':
        movie_name = request.form['movie']
        recommendations = recommend(movie_name)
    return render_template('index.html', recommendations=recommendations, input_movie=movie_name)

if __name__ == '__main__':
    app.run(debug=True)
